﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Boteco
{
    public partial class FrmCliente : Form
    {
        public FrmCliente()
        {
            InitializeComponent();
        }

        private void FrmCliente_Load(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            List<Cliente> clientes = cliente.listacliente();
            dgvCliente.DataSource = clientes;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnEditar_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtId.Text.Trim());
            string celular = Convert.ToString(txtCelular.Text);
            Cliente clientes = new Cliente();
            clientes.Atualizar(Id, txtNome.Text, txtCPF.Text, txtData.Text, celular);
            MessageBox.Show("Jogo atualizado com sucesso!");
            List<Cliente> cliente = clientes.listacliente();
            dgvCliente.DataSource = clientes;
            txtId.Text = "";
            txtNome.Text = "";
            txtCPF.Text = "";
            txtData.Text = "";
            txtCelular.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.txtNome.Focus();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtId.Text.Trim());
            Cliente cliente = new Cliente();
            cliente.Excluir(Id);
            MessageBox.Show("Jogo deletado com sucesso!");
            List<Cliente> clientes = cliente.listacliente();
            dgvCliente.DataSource = clientes;
            txtId.Text = "";
            txtNome.Text = "";
            txtCPF.Text = "";
            txtData.Text = "";
            txtCelular.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.txtNome.Focus();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            if (txtId.Text == "")
            {
                MessageBox.Show("Por favor digite um Id!");
            }
            else
            {
                int Id = Convert.ToInt32(txtId.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Localizar(Id);
                txtNome.Text = cliente.nome;
                txtCPF.Text = cliente.cpf;
                txtData.Text = cliente.data;
                txtCelular.Text = Convert.ToString(cliente.celular);
                btnEditar.Enabled = true;
                btnExcluir.Enabled = true;


            }
        }

        private void dgvCliente_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvCliente.Rows[e.RowIndex];
                row.Selected = true;
                txtId.Text = row.Cells[0].Value.ToString();
                txtNome.Text = row.Cells[1].Value.ToString();
                txtCPF.Text = row.Cells[2].Value.ToString();
                txtData.Text = row.Cells[3].Value.ToString();
                txtCelular.Text = row.Cells[4].Value.ToString();
                btnEditar.Enabled = true;
                btnExcluir.Enabled = true;
            }
        }

        private void btnInserir_Click_1(object sender, EventArgs e)
        {
            if (txtNome.Text == "" && txtCPF.Text == "")
            {
                MessageBox.Show("Preencha o formulário!");
                this.txtNome.Focus();
            }
            else
            {
                Cliente cliente = new Cliente();
                if (cliente.RegistroRepetido(txtNome.Text) != false)
                {
                    MessageBox.Show("Este jogo já foi cadastrado!");
                    this.txtNome.Focus();
                }
                else
                {
                    string celular = Convert.ToString(txtCelular.Text);
                    cliente.Inserir(txtNome.Text, txtCPF.Text, txtData.Text, celular);
                    MessageBox.Show("Cliente cadastrado com sucesso!");
                    List<Cliente> clientes = cliente.listacliente();
                    dgvCliente.DataSource = clientes;
                    txtNome.Text = "";
                    txtCPF.Text = "";
                    txtData.Text = "";
                    txtCelular.Text = "";
                    this.txtNome.Focus();
                }
            }
        }

        private void btnEditar_Click_1(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtId.Text.Trim());
            string celular = Convert.ToString(txtCelular.Text);
            Cliente clientes = new Cliente();
            clientes.Atualizar(Id, txtNome.Text, txtCPF.Text, txtData.Text, celular);
            MessageBox.Show("Jogo atualizado com sucesso!");
            List<Cliente> cliente = clientes.listacliente();
            dgvCliente.DataSource = clientes;
            txtId.Text = "";
            txtNome.Text = "";
            txtCPF.Text = "";
            txtData.Text = "";
            txtCelular.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.txtNome.Focus();
        }
    }
}