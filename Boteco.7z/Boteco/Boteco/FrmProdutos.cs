﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Boteco
{
    public partial class FrmProdutos : Form
    {
        public FrmProdutos()
        {
            InitializeComponent();
        }

        private void FrmProdutos_Load(object sender, EventArgs e)
        {
            Produtos produto = new Produtos();
            List<Produtos> itens = produto.listaprodutos();
            dgvProduto.DataSource = itens;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtId.Text.Trim());
            int quantidade = Convert.ToInt32(txtId.Text.Trim());

            Produtos produtos = new Produtos();
            produtos.Atualizar(Id, txtNome.Text, textTipo.Text, quantidade, txtPreco.Text);
            MessageBox.Show("Produto atualizado com sucesso!");
            List<Produtos> produto = produtos.listaprodutos();
            dgvProduto.DataSource = produtos;
            txtId.Text = "";
            txtNome.Text = "";
            textTipo.Text = "";
            txtQuantidade.Text = "";
            txtPreco.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.txtNome.Focus();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(txtId.Text.Trim());
            Produtos produto = new Produtos();
            produto.Excluir(Id);
            MessageBox.Show("Produto deletado com sucesso!");
            List<Produtos> produtos = produto.listaprodutos();
            dgvProduto.DataSource = produtos;
            txtId.Text = "";
            txtNome.Text = "";
            textTipo.Text = "";
            textQuantidade.Text = "";
            txtPreco.Text = "";
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.txtNome.Focus();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            if (txtId.Text == "")
            {
                MessageBox.Show("Por favor digite um Id!");
            }
            else
            {
                int Id = Convert.ToInt32(txtId.Text.Trim());
                Produtos produto = new Produtos();
                produto.Localizar(Id);
                txtNome.Text = produto.nome;
                textTipo.Text = produto.tipo;
                textQuantidade.Text = Convert.ToString(produto.quantidade);
                txtPreco.Text = Convert.ToString(produto.preco);
                btnEditar.Enabled = true;
                btnExcluir.Enabled = true;


            }
        }

        private void dgvProduto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvProduto.Rows[e.RowIndex];
                row.Selected = true;
                txtId.Text = row.Cells[0].Value.ToString();
                txtNome.Text = row.Cells[1].Value.ToString();
                textTipo.Text = row.Cells[2].Value.ToString();
                txtQuantidade.Text = row.Cells[3].Value.ToString();
                txtPreco.Text = row.Cells[4].Value.ToString();
                btnEditar.Enabled = true;
                btnExcluir.Enabled = true;
            }
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "" && textTipo.Text == "")
            {
                MessageBox.Show("Preencha o formulário!");
                this.txtNome.Focus();
            }
            else
            {
                Produtos produto = new Produtos();
                if (produto.RegistroRepetido(txtNome.Text) != false)
                {
                    MessageBox.Show("Este produto já foi cadastrado!");
                    this.txtNome.Focus();
                }
                else
                {
                    int quantidade = Convert.ToInt32(txtQuantidade.Text.Trim());
                    produto.Inserir(txtNome.Text, textTipo.Text, quantidade, txtPreco.Text);
                    MessageBox.Show("Produto cadastrado com sucesso!");
                    List<Produtos> produtos = produto.listaprodutos();
                    dgvProduto.DataSource = produtos;
                    txtNome.Text = "";
                    textTipo.Text = "";
                    txtQuantidade.Text = "";
                    txtPreco.Text = "";
                    this.txtNome.Focus();
                }
            }
        }

        private void textQuantidade_TextChanged(object sender, EventArgs e)
        {

        }
    }
}